-- 1. Customer spend using JOIN
SELECT c.Customer_ID, c.Customer_Name,
       COUNT(s.Order_ID) AS order_count,
       NVL(SUM(s.Sales), 0) AS total_spending
FROM Customers c
LEFT JOIN Retail_Sales s ON s.Customer_ID = c.Customer_ID
GROUP BY c.Customer_ID, c.Customer_Name
ORDER BY total_spending DESC;

-- 2. Customers without orders (LEFT JOIN)
SELECT c.Customer_ID, c.Customer_Name, c.City
FROM Customers c
LEFT JOIN Retail_Sales s ON s.Customer_ID = c.Customer_ID
WHERE s.Order_ID IS NULL
ORDER BY c.Customer_ID;

-- 3. Sales records grouped by customer segment
SELECT c.Customer_Segment, COUNT(s.Order_ID) AS order_count,
       NVL(SUM(s.Sales), 0) AS revenue,
       NVL(SUM(s.Profit), 0) AS profit
FROM Customers c
LEFT JOIN Retail_Sales s ON s.Customer_ID = c.Customer_ID
GROUP BY c.Customer_Segment
ORDER BY revenue DESC;

-- 4. Performance band (illustrative thresholds)
SELECT Order_ID, Sales, Profit,
       CASE WHEN Profit >= 10000 THEN 'High Profit'
            WHEN Profit >= 3000 THEN 'Medium Profit'
            ELSE 'Low Profit' END AS profit_band
FROM Retail_Sales;

-- 5. Data quality check: Profit should equal Sales - Cost
SELECT COUNT(*) AS rows_with_profit_mismatch
FROM Retail_Sales
WHERE ABS(Profit - (Sales - Cost)) > 0.02;

-- 6. Check for duplicate primary keys (should return no rows)
SELECT Order_ID, COUNT(*) AS row_count
FROM Retail_Sales
GROUP BY Order_ID
HAVING COUNT(*) > 1;
