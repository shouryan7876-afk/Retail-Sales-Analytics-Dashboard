-- Optional views to simplify Tableau connections.
CREATE OR REPLACE VIEW VW_RETAIL_MONTHLY AS
SELECT TRUNC(Order_Date, 'MM') AS Month_Start,
       Category, Department, Region,
       SUM(Sales) AS Revenue, SUM(Profit) AS Profit,
       SUM(Units_Sold) AS Units_Sold,
       COUNT(*) AS Order_Count
FROM Retail_Sales
GROUP BY TRUNC(Order_Date, 'MM'), Category, Department, Region;

CREATE OR REPLACE VIEW VW_RETAIL_PRODUCT AS
SELECT Product, Category, Department,
       SUM(Sales) AS Revenue, SUM(Profit) AS Profit,
       SUM(Units_Sold) AS Units_Sold
FROM Retail_Sales
GROUP BY Product, Category, Department;
