-- 1. Overall KPI summary
SELECT COUNT(*) AS total_orders, SUM(Units_Sold) AS total_units,
       SUM(Sales) AS total_revenue, SUM(Cost) AS total_cost,
       SUM(Profit) AS total_profit,
       ROUND(100 * SUM(Profit) / NULLIF(SUM(Sales), 0), 2) AS profit_margin_pct
FROM Retail_Sales;

-- 2. Monthly trend
SELECT TO_CHAR(Order_Date, 'YYYY-MM') AS sales_month,
       SUM(Sales) AS revenue, SUM(Profit) AS profit
FROM Retail_Sales
GROUP BY TO_CHAR(Order_Date, 'YYYY-MM')
ORDER BY sales_month;

-- 3. Category performance
SELECT Category, SUM(Sales) AS revenue, SUM(Profit) AS profit,
       SUM(Units_Sold) AS units_sold
FROM Retail_Sales
GROUP BY Category
ORDER BY revenue DESC;

-- 4. Department performance
SELECT Department, SUM(Sales) AS revenue, SUM(Profit) AS profit
FROM Retail_Sales
GROUP BY Department
ORDER BY profit DESC;

-- 5. Regional performance
SELECT Region, SUM(Sales) AS revenue, SUM(Profit) AS profit
FROM Retail_Sales
GROUP BY Region
ORDER BY revenue DESC;

-- 6. Top five products by revenue
SELECT Product, revenue
FROM (
  SELECT Product, SUM(Sales) AS revenue
  FROM Retail_Sales
  GROUP BY Product
  ORDER BY SUM(Sales) DESC
)
WHERE ROWNUM <= 5;

-- 7. Average order value (simplified: one row per order)
SELECT ROUND(AVG(Sales), 2) AS average_order_value
FROM Retail_Sales;

-- 8. Monthly / category drill-down
SELECT TRUNC(Order_Date, 'MM') AS month_start, Category,
       SUM(Sales) AS revenue
FROM Retail_Sales
GROUP BY TRUNC(Order_Date, 'MM'), Category
ORDER BY month_start, Category;
