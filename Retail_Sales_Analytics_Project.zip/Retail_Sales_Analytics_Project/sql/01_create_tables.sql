-- Oracle Database 21c XE
-- Run as your own project schema user, not necessarily SYSTEM.
CREATE TABLE Customers (
    Customer_ID NUMBER(10) PRIMARY KEY,
    Customer_Name VARCHAR2(100) NOT NULL,
    City VARCHAR2(60),
    Region VARCHAR2(30),
    Customer_Segment VARCHAR2(30)
);

CREATE TABLE Retail_Sales (
    Order_ID NUMBER(10) PRIMARY KEY,
    Order_Date DATE NOT NULL,
    Product VARCHAR2(80) NOT NULL,
    Category VARCHAR2(50),
    Department VARCHAR2(50),
    Region VARCHAR2(30),
    Units_Sold NUMBER(10) CHECK (Units_Sold >= 0),
    Sales NUMBER(14,2) CHECK (Sales >= 0),
    Cost NUMBER(14,2) CHECK (Cost >= 0),
    Profit NUMBER(14,2),
    Customer_ID NUMBER(10),
    CONSTRAINT fk_sales_customer FOREIGN KEY (Customer_ID)
      REFERENCES Customers(Customer_ID)
);

-- Helpful index for common filters
CREATE INDEX idx_sales_date ON Retail_Sales(Order_Date);
CREATE INDEX idx_sales_category ON Retail_Sales(Category);
