# Windows Setup and Troubleshooting

## SQL Developer
- Run scripts in the correct order: `01_create_tables.sql`, then `02_insert_sample_data.sql`, then analysis scripts.
- Use **F5 / Run Script** for scripts containing many INSERT statements.
- Connect with a project schema user that has CREATE TABLE and related privileges. Avoid doing project work as SYSTEM if you have a separate user.
- Oracle XE 21c often uses port 1521. The service name may be `XEPDB1`; check your local connection settings. Worksheet examples may use SID `xe`, but service-name configuration is common for pluggable databases.
- If tables already exist, either drop them carefully or use a fresh schema before rerunning create scripts.

## Excel
- If formulas do not recalculate, open the workbook in Excel and use Formulas → Calculation Options → Automatic.
- The workbook includes source data and formulas. Native Pivot Tables are created through Excel's Insert → PivotTable workflow.

## Tableau
- If Oracle is unavailable in Tableau, use the bundled CSV file.
- If Oracle connection fails, check host, port, service name, username, password and whether the Oracle listener/database are running.
- Install the official compatible Oracle driver if Tableau requests it.

## Python (optional validation)
Open Command Prompt in the extracted project folder and run:
```bat
py -m pip install -r requirements.txt
py pythonalidate_data.py
```
If `py` is unavailable, try `python` instead.
