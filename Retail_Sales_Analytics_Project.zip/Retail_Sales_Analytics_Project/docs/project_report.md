# Retail Sales Analytics Dashboard — Mini Project Report

## Abstract
This project demonstrates a retail sales analysis workflow using Oracle SQL, Microsoft Excel and Tableau. A reproducible synthetic dataset of 800 sales records and 120 customers is provided. SQL queries summarize revenue, profit, product performance, monthly trends and customer spending. Excel formulas and summary sheets support spreadsheet analysis, while Tableau is used to build an interactive dashboard.

## 1. Introduction
Retail businesses need to understand sales patterns, profitable products, regional performance and changes over time. Data analytics turns transactional records into summaries that support informed decisions.

## 2. Problem Statement
Raw retail transactions are difficult to compare manually. The project organizes sales data and creates reusable queries, spreadsheet summaries and visual dashboard specifications.

## 3. Objectives
- Summarize total revenue, cost, profit and units sold.
- Compare products, categories, departments and regions.
- Examine monthly sales trends.
- Demonstrate Excel logical and conditional functions.
- Practice Oracle SQL aggregation and joins.
- Design an interactive Tableau dashboard.

## 4. Tools
- Oracle Database 21c XE and SQL Developer
- Microsoft Excel
- Tableau Desktop (or an available Tableau edition that supports the required dashboard workflow)
- Python for dataset validation and optional export

## 5. Methodology
1. Generate synthetic customer and retail sales records.
2. Validate identifiers, numeric fields and profit calculations.
3. Create Oracle tables and load the data.
4. Execute SQL analysis queries.
5. Review Excel formulas and summary sheets; create Pivot Tables in Excel.
6. Connect Tableau to the CSV or Oracle source and build dashboard worksheets.
7. Interpret results from the actual charts after they are generated.

## 6. Dataset
The dataset contains 800 order-line records dated in 2025, ten product types across four categories, five regions and 120 customer records. All data is synthetic and intended for educational practice. Amounts are illustrative INR values.

## 7. Analysis
The included SQL files cover KPI summaries, monthly revenue, category and department performance, regional comparisons, top products, average order value, customer spending, customers without orders and a profit consistency check. Exact findings should be reported from query output or Tableau, not assumed in advance.

## 8. Expected Deliverables
- Oracle DDL and data insertion scripts
- CSV datasets
- Excel workbook with raw data, formulas and summary tables
- Tableau dashboard design guide and calculated fields
- Project documentation and viva preparation

## 9. Limitations
- Synthetic data does not represent a real retailer.
- The Excel workbook contains formulas and prepared summary sheets, but native Pivot Table objects must be created in Excel.
- A native Tableau workbook is not included; the dashboard must be assembled in Tableau Desktop.
- The Oracle import uses a simplified model where each sales row is treated as one order line and one order for the teaching exercise.

## 10. Conclusion
The project integrates spreadsheet analysis, relational database queries and dashboard visualization. It provides a practical foundation for analyzing sales performance and communicating findings through charts and KPIs.

## 11. Future Scope
Add returns and discount data, compare multiple years, create a normalized order/order-line schema, and connect the dashboard to regularly refreshed data.
