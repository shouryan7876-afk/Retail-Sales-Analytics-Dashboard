# Viva Questions and Answers

1. **What is data analytics?** The process of inspecting and summarizing data to find useful patterns and support decisions.
2. **What is a KPI?** A key performance indicator is a measurable value used to track performance.
3. **What is revenue?** The total sales amount earned before subtracting costs.
4. **What is profit?** In this dataset, Profit = Sales − Cost.
5. **What is a primary key?** A column or combination of columns that uniquely identifies a row.
6. **What is a foreign key?** A field that references a key in another table to maintain relationships.
7. **What does GROUP BY do?** It groups rows with matching values so aggregate calculations can be made.
8. **What is SUM()?** An aggregate function that adds numeric values.
9. **What is a LEFT JOIN?** It returns all rows from the left table and matching rows from the right table, with NULLs where there is no match.
10. **Why use COALESCE or NVL?** To replace NULL with a chosen fallback value.
11. **What is ORDER BY?** It sorts query results.
12. **What is a Pivot Table?** An Excel feature that summarizes data by categories, rows, columns, values and filters.
13. **What does SUMIF do?** It adds values that meet a specified condition.
14. **What does COUNTIF do?** It counts cells that meet a condition.
15. **What does AVERAGEIF do?** It averages values matching a condition.
16. **Why use IFERROR?** To return a fallback value when a formula results in an error.
17. **What is Tableau?** A data visualization and business intelligence tool for building charts and dashboards.
18. **What is a dashboard?** A combined view of multiple visualizations and KPIs.
19. **Why add filters to Tableau?** They let viewers focus on selected dates, categories, departments or regions.
20. **What is a calculated field?** A field created from an expression using existing data.
21. **What is profit margin?** Profit divided by revenue, commonly shown as a percentage.
22. **What is average order value?** Total revenue divided by the number of distinct orders.
23. **Why validate data?** To catch missing values, duplicates, invalid relationships and incorrect calculations.
24. **Is this dataset real?** No, it is synthetic and was generated for educational practice.
25. **What are the limitations?** Synthetic data, simplified order structure and manual Tableau dashboard assembly.
