# Excel Analysis Guide

Open `retail_sales_analysis.xlsx` in Microsoft Excel.

## Sheets
- **Raw_Data**: 800 synthetic order-line records in a formatted Excel table (`RetailSalesTable`).
- **Summary**: formula-based KPIs for revenue, profit, units, order count, average order value and profit margin.
- **Product_Analysis**: product/category totals and profit margin.
- **Monthly_Analysis**: monthly totals ready for a line chart.
- **Department_Analysis**: department totals ready for comparison.
- **Excel_Formulas**: examples of IF, Nested IF, AND, OR, NOT, IFERROR, SUMIF, COUNTIF and AVERAGEIF.

## Create Pivot Tables
1. Select a cell in `Raw_Data`.
2. Choose **Insert → PivotTable → From Table/Range**.
3. Create a new worksheet.
4. For department/product analysis: put `Department` in Rows, `Product` in Columns, and `Sales` in Values (Sum).
5. For monthly trend: put `Order_Date` in Rows and `Sales` in Values; right-click a date and choose Group → Months.
6. Add `Category` or `Region` to Filters to compare subsets.
7. Refresh the Pivot Table after changing source data.

Excel formula results may initially appear blank in preview tools; open the workbook in Excel and allow calculation. The workbook includes source data and formulas, not native Pivot Table objects.
