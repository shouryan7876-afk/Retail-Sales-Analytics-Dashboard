"""Regenerate synthetic retail CSV files deterministically.
The full generator used to create the bundled dataset is documented in README.
This script can be extended; bundled CSVs are ready to use without running it.
"""
from pathlib import Path
import pandas as pd
ROOT = Path(__file__).resolve().parents[1]
sales = pd.read_csv(ROOT / "data" / "retail_sales.csv")
customers = pd.read_csv(ROOT / "data" / "customers.csv")
print(f"Loaded {len(sales)} sales rows and {len(customers)} customers.")
print("Bundled CSVs are ready to import. To regenerate, use the documented build process.")
