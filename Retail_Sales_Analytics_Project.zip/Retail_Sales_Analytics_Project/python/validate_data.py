from pathlib import Path
import pandas as pd
ROOT = Path(__file__).resolve().parents[1]
sales = pd.read_csv(ROOT / "data" / "retail_sales.csv")
customers = pd.read_csv(ROOT / "data" / "customers.csv")
checks = {
    "at least 500 sales rows": len(sales) >= 500,
    "unique Order_ID": sales["Order_ID"].is_unique,
    "no missing required values": not sales[["Order_ID", "Order_Date", "Product", "Sales", "Cost", "Profit", "Customer_ID"]].isna().any().any(),
    "profit equals sales minus cost": ((sales["Profit"] - (sales["Sales"] - sales["Cost"])).abs() <= 0.02).all(),
    "all customer references exist": set(sales["Customer_ID"]).issubset(set(customers["Customer_ID"])),
}
for name, passed in checks.items():
    print(f"{'PASS' if passed else 'FAIL'}: {name}")
if not all(checks.values()):
    raise SystemExit("One or more validation checks failed.")
print("Validation complete.")
