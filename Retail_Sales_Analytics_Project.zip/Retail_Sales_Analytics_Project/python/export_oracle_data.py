"""Optional Oracle-to-CSV export helper.
Install oracledb (`pip install oracledb`) and configure credentials locally.
Never put passwords in source code. This script prompts for a password.
"""
import getpass
import csv
try:
    import oracledb
except ImportError:
    raise SystemExit("Install optional dependency first: pip install oracledb")
user = input("Oracle username (e.g. your project schema): ").strip()
password = getpass.getpass("Oracle password: ")
dsn = input("DSN (e.g. localhost:1521/XEPDB1): ").strip()
out = input("Output CSV path [oracle_export.csv]: ").strip() or "oracle_export.csv"
with oracledb.connect(user=user, password=password, dsn=dsn) as conn:
    with conn.cursor() as cur, open(out, "w", newline="", encoding="utf-8-sig") as fh:
        cur.execute("SELECT Order_ID, Order_Date, Product, Category, Department, Region, Units_Sold, Sales, Cost, Profit, Customer_ID FROM Retail_Sales ORDER BY Order_ID")
        writer = csv.writer(fh)
        writer.writerow([d[0] for d in cur.description])
        for row in cur:
            writer.writerow(row)
print(f"Exported to {out}")
