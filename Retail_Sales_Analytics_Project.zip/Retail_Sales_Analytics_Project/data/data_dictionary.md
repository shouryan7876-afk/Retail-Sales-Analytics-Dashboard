# Data Dictionary

All records are **synthetic and generated locally** for educational use. Currency values are illustrative INR amounts.

## retail_sales.csv
| Column | Meaning |
|---|---|
| Order_ID | Unique order/line identifier (primary key in this simplified dataset) |
| Order_Date | Order date in ISO `YYYY-MM-DD` format |
| Product | Product name |
| Category | Product category |
| Department | Business department |
| Region | Sales region |
| Units_Sold | Units sold on the order line |
| Sales | Total sales amount for the order line (INR) |
| Cost | Total cost for the order line (INR) |
| Profit | Sales minus Cost (INR) |
| Customer_ID | Customer reference |

## customers.csv
Customer_ID (unique key), Customer_Name, City, Region, Customer_Segment.

## orders.csv
Order_ID, Order_Date, Customer_ID, Order_Amount. Each order corresponds to one sales line in this simplified teaching dataset.
