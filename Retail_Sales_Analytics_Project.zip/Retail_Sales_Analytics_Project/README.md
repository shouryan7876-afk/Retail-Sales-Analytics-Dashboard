# Retail Sales Analytics Dashboard

A college mini-project integrating Oracle SQL, Excel and Tableau.

## Project contents
- `data/`: synthetic sales, customer and order CSV files plus data dictionary
- `sql/`: Oracle 21c-compatible table creation, data load and analysis scripts
- `excel/`: populated Excel workbook and Pivot Table instructions
- `tableau/`: dashboard design guide and calculated fields
- `python/`: data validation and optional Oracle export utilities
- `docs/`: report, viva questions and troubleshooting

## Dataset
The bundled dataset contains 800 synthetic sales records dated in 2025 and 120 customers. Values are generated for education and are not real business data.

## Windows setup
1. Extract the ZIP to a folder such as `C:\DataAnalytics\Retail_Sales_Analytics_Project`.
2. Open `excel\retail_sales_analysis.xlsx` in Excel.
3. Open SQL Developer and connect to your project schema. Use a dedicated schema user with required privileges when possible.
4. Run `sql\01_create_tables.sql` with F5.
5. Run `sql\02_insert_sample_data.sql` with F5. This loads the synthetic data and commits it.
6. Run `sql\03_basic_analysis.sql` and `sql\04_advanced_analysis.sql` query-by-query or as scripts.
7. Optionally run `sql\05_tableau_views.sql` to create aggregate views.
8. Open Tableau Desktop and connect to `data\retail_sales.csv` using Text File, or use the Oracle connector if installed/configured.
9. Follow `tableau\Tableau_Dashboard_Guide.md` and `tableau\calculated_fields.md`.

## Python validation (optional)
Install Python 3.10+ and run:
```bat
py -m pip install -r requirements.txt
py python\validate_data.py
```

## Important notes
- Do not store your Oracle password in the project files.
- Oracle service names vary by installation. Confirm your service name; `XEPDB1` is common for Oracle XE 21c pluggable databases.
- The Excel workbook has formula-based KPIs and summary sheets. Create native Pivot Tables in Excel using the guide.
- The Tableau dashboard guide provides the steps to assemble the dashboard; a native Tableau workbook is not included.
- All data is synthetic.
