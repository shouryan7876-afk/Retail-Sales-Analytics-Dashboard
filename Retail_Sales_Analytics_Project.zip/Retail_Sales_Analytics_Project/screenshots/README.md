Add your own screenshots here after running the SQL queries and building the Tableau dashboard. No screenshots are fabricated or included.
