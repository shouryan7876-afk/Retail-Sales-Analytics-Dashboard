# Tableau Calculated Fields

Create these in **Analysis → Create Calculated Field**.

## Profit Margin
```tableau
IF SUM([Sales]) = 0 THEN 0
ELSE SUM([Profit]) / SUM([Sales])
END
```
Format as Percentage.

## Average Order Value
```tableau
SUM([Sales]) / COUNTD([Order_ID])
```

## Order Month
```tableau
DATETRUNC('month', [Order_Date])
```

## Profit Status
```tableau
IF SUM([Profit]) >= 10000 THEN "High Profit"
ELSEIF SUM([Profit]) >= 3000 THEN "Medium Profit"
ELSE "Low Profit"
END
```

## Sales per Unit
```tableau
IF SUM([Units_Sold]) = 0 THEN 0
ELSE SUM([Sales]) / SUM([Units_Sold])
END
```

Note: thresholds are illustrative for this synthetic dataset and can be adjusted after reviewing the data.
