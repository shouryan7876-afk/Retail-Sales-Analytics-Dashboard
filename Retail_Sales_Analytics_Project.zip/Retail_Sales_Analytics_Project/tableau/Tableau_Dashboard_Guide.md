# Tableau Dashboard Guide

## Recommended data source
Use `../data/retail_sales.csv` for the simplest connection, or connect Tableau Desktop to Oracle after importing the SQL data.

## Connect using CSV
1. Open Tableau Desktop.
2. Under Connect, choose **Text File** and select `data/retail_sales.csv`.
3. Verify `Order_Date` is a Date and Sales/Cost/Profit are numeric.
4. Open a worksheet and create the sheets below.

## Build worksheets
1. **Monthly Revenue**: Order_Date → Columns (set to MONTH); SUM(Sales) → Rows; choose Line.
2. **Sales by Category**: Category → Rows; SUM(Sales) → Columns; sort descending.
3. **Profit by Department**: Department → Rows; SUM(Profit) → Columns.
4. **Regional Sales**: Region → Rows; SUM(Sales) → Columns.
5. **Top Products**: Product → Rows; SUM(Sales) → Columns; filter Product → Top → Top 5 by SUM(Sales).
6. **KPI cards**: create separate sheets with SUM(Sales), SUM(Profit), SUM(Units_Sold), and COUNTD(Order_ID) as text.

## Dashboard layout
- Size: Automatic or Desktop Browser.
- Top row: four KPI cards.
- Middle row: monthly revenue trend and category sales.
- Bottom row: department profit, regional sales, top five products.
- Add filters for Order_Date, Category, Department and Region.
- For each filter menu, choose **Apply to Worksheets → All Using This Data Source**.
- Add a clear title and currency formatting (INR / ₹). Label all charts.

## Oracle connection (optional)
1. Ensure the data is loaded into Oracle using the included SQL scripts.
2. In Tableau, choose **Oracle** under Connect.
3. Install the Oracle driver if Tableau prompts you to.
4. Enter server `localhost`, port `1521`, your schema username, and the correct service name. For Oracle XE 21c, service names often include `XEPDB1`; confirm your actual service/configuration rather than assuming.
5. Select `RETAIL_SALES` or the optional views and click Sheet 1.
6. Never put your database password in project files.

## Suggested calculated fields
See `calculated_fields.md`. A native Tableau workbook is not included; follow these steps to build it in Tableau Desktop.
